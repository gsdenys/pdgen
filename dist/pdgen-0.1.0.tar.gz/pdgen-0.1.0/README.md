# PostgreSQL Data Dictionary Generator

## Command Line


## Web API


## Web UI


pytest --cov-report lcov:coverage/lcov.info tests/